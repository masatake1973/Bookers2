Rails.application.routes.draw do

  devise_for :users
  root 'homes#top'
  get 'home/about', to: 'homes#about'
  resources :users, only: [:index, :show, :edit, :update] # 変更
  resources :books, only: [:index, :show, :edit, :new, :destroy, :create, :update] # 追加
end